var express = require('express');
var router = express.Router();
 var GAPI = require('gapitoken'),
  	 request = require('request'),
   	 fs = require('fs'),
     util = require('util')

/* GET users listing. */
router.get('/', function(req, res, next) {

 console.log("******Big Query Called******");

   
//From admin console, create a service account, save the client_secrets.json and it's key
var client_secrets = 'axisbank-bigquery-8af5eece083f.json';
//Project setting
var iss = 'abhijeet-dev@axisbank-bigquery.iam.gserviceaccount.com'; 
//BigQuery scopes list
var bq_scope = 'https://www.googleapis.com/auth/bigquery https://www.googleapis.com/auth/cloud-platform';
var project = 'axisbank-bigquery';
var opts = {
    iss: iss,
    scope: bq_scope,
    //keyFile: __dirname + 'axisGA.pem'  //pem key path
	keyFile:'axis.pem'
}; 
 
/**
 * Translate p12 to pem
 */
var _token = '';
var gapi = new GAPI(opts, function(err) {
  if (err) return console.log(err);
  gapi.getToken(function(err, token) {
    if (err)  return console.log(err);
    _token = token;
    var bqurl = 'https://www.googleapis.com/bigquery/v2/projects/%s/queries'; //Query api url
    request({
      url: util.format(bqurl,project),
      method: 'POST',
      headers: {
        "Authorization": "Bearer " + _token
      },
      json: {
        query: 'SELECT visitorId , totals.visits, visitNumber, visitStartTime, totals.hits, totals.pageviews, totals.transactions, userId, fullVisitorId FROM [105952790.ga_sessions_20160602] LIMIT 100' //Here, you can put your query here...
      }
    }, function(e,r,d){
      if(e) console.log(e);
      //Print the query result
      console.log(JSON.stringify(d));
      res.send(d);
    });
  });
});
   

    /////////
  //res.render('index', { title: 'Express' });	
  
});

module.exports = router;
