var express = require('express');
var router = express.Router();
var Http = require('http');
var auth = 'jbdon.pem';
var googleapis = require('googleapis'),
    JWT = googleapis.auth.JWT,

    analytics = googleapis.analytics('v3');

var SERVICE_ACCOUNT_EMAIL = 'abhijeet-dev@axisbank-bigquery.iam.gserviceaccount.com';
var SERVICE_ACCOUNT_KEY_FILE = 'axis.pem';  
//var SERVICE_ACCOUNT_EMAIL = 'jbdon-683@jbdon-1335.iam.gserviceaccount.com';
//var SERVICE_ACCOUNT_KEY_FILE = 'jbdon.pem'; 

/* GET home page. */
router.get('/', function(req, res, next) {
	//////////

	/////////
  res.render('index', { title: 'Express' });
});

////////GA 

router.get('/gA', function(req, res, next) {
    //////////
    console.log("EMAIL is: "+SERVICE_ACCOUNT_EMAIL+" SERVICE_ACCOUNT_KEY_FILE: "+SERVICE_ACCOUNT_KEY_FILE);
    var authClient = new JWT(
    SERVICE_ACCOUNT_EMAIL,
    SERVICE_ACCOUNT_KEY_FILE,
    null,
    ['https://www.googleapis.com/auth/analytics.readonly']
);

authClient.authorize(function(err, tokens) {
    if (err) {
        console.log(err);
        return;
    }
console.log("TOKENS: "+JSON.stringify(tokens));
    analytics.data.ga.get({ 
        auth: authClient,
        'ids': 'ga:59156596',
         //'ids': 'ga:31117768',
        'start-date': '2016-05-01',
        'end-date': '2016-06-10',
        'metrics': 'ga:sessions'
    }, function(err, result) {
        console.log(err);
        console.log(result);

        res.send(result);
    });
});

    /////////
  //res.render('index', { title: 'Express' });
});

//////BQuery
router.get('/bquery', function(req, res, next) {
    //////////
   
   //////////
});

module.exports = router;
