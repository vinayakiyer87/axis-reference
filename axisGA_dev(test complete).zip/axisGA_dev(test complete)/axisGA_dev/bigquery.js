/*var Http = require('http');
var Tls = require('tls');
var HttpsProxyAgent = require('https-proxy-agent');
var Https = require('https');
var agent = new HttpsProxyAgent({
    proxyHost: '10.9.138.21',
    proxyPort: 1050
});
Https.request({
    // like you'd do it usually...
    host: 'localhost',
    port: 3000,
    method: 'GET',
 /*   path: 'https://www.googleapis.com/auth/analytics.readonly',*/
    /* path: 'https://www.accounts.google.com',
 
    // ... just add the special agent:
    agent: agent
}, function (res) {
    res.on('data', function (data) {
        console.log(data.toString());
    });
}).end();*/


var GAPI = require('gapitoken')
  , request = require('request')
  , fs = require('fs')
  , util = require('util')
//From admin console, create a service account, save the client_secrets.json and it's key
var client_secrets = JSON.parse(fs.readFileSync(__dirname + '/axisbank-bigquery-8af5eece083f.json','utf8'));
//Project setting
var iss = 'abhijeet-dev@axisbank-bigquery.iam.gserviceaccount.com'; 
//BigQuery scopes list
var bq_scope = 'https://www.googleapis.com/auth/bigquery https://www.googleapis.com/auth/cloud-platform';
var project = 'axisbank-bigquery';
var opts = {
    iss: iss,
    scope: bq_scope,
    keyFile: __dirname + '/axisGA.pem'  //pem key path
}; 
 
/**
 * Translate p12 to pem
 */
var _token = '';
var gapi = new GAPI(opts, function(err) {
  if (err) return console.log(err);
  gapi.getToken(function(err, token) {
    if (err)  return console.log(err);
    _token = token;
    var bqurl = 'https://www.googleapis.com/bigquery/v2/projects/%s/queries'; //Query api url
    request({
      url: util.format(bqurl,project),
      method: 'POST',
      headers: {
        "Authorization": "Bearer " + _token
      },
      json: {
        query: 'SELECT visitorId , totals.visits, visitNumber, visitStartTime, totals.hits, totals.pageviews, totals.transactions, userId, fullVisitorId FROM [105952790.ga_sessions_20160602] LIMIT 10' //Here, you can put your query here...
      }
    }, function(e,r,d){
      if(e) console.log(e);
      //Print the query result
      console.log(JSON.stringify(d));
    });
  });
});