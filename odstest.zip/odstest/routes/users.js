var express = require('express');
var router = express.Router();
var oracledb = require('oracledb');
var fs = require('fs');

/* GET users listing. */
router.get('/', function(req, res, next) {
	console.log(" ORA CALLED");
	var query = req.query.query;
	console.log(" QUERY FROM HTML >>>>> "+query);
	 try {
        oracledb.getConnection({
                user: "system",
                password: "password",
                connectString: "localhost:1521/orcl"

                /*user: "big_query",
                password: "axis#1234",
                connectString: "10.9.112.237:44106/AXBIGQ"*/
            },
            function(err, connection) {
                try {
                    if (err) {
                        console.log("ERROR IN ODS CONNECTION: " + err);
                    };

                    connection.execute(
                        //'select * from BQ_UPLOAD1',
                        query, {}, //no binds
                        {
                            resultSet: true,
                            prefetchRows: 1000
                        },
                        function(err, results) {
                            try {
                                var rowsProcessed = 0;
                                var startTime;
                                var val = "";
                                if (err) {
                                    console.log("Err: " + err);
                                }

                                startTime = Date.now();

                                function processResultSet() {

                                    results.resultSet.getRows(1000, function(err, rows) {
                                        if (err) throw err;

                                        if (rows.length) {
                                            var val = "";

                                            for (i = 0; i < rows.length; i++) {
                                                rowsProcessed += 1;
                                                val += rows[i].concat('\n');
                                                // console.log("NUMBER OF ROWS:  "+rows[i]);                        
                                            }
                                            //display entire data log
                                            //console.log(" THIS IS THE VAL: "+val);

                                            fs.appendFile('csvdata/' + '1.csv', val, 'utf8', function(err) {
                                                if (err) {
                                                    console.log('Some error occured - ' + err);

                                                } else {
                                                    console.log('It\'s saved!' + '.csv');
                                                }
                                            })
                                            /* rows.forEach(function(row) {
                                                 
                                                 
                                                 //do work on the row here        
                                                //console.log("THIS ARE ROWS: "+row); 
                                                console.log("ROW "+row ); 
                                                val+=row;
                                              // val += row.replace(/\"/g, "").replace(/\[/g, "").replace(/\]/g, "").concat('\n');
                                                                 
                                             });*/

                                            processResultSet(); //try to get more rows from the result set                            
                                            return; //exit recursive function prior to closing result set
                                        }
                                        //console.log("THESE ARE VALUES2222: "+values);
                                        console.log('Finish processing ' + rowsProcessed + ' rows');
                                        console.log('Total time (in seconds):', ((Date.now() - startTime) / 1000));
                                        console.log(" #### CSV COMPLETELY GENERATED #######");
                                        var filename = './csv-data/1.csv';
                                        // call the rest of ./csv-data/1.csvthe code and have it execute after 10 seconds
                                      /*  setTimeout(function() {
                                            convertGZ(filename);
                                        }, 10000);*/

                                        results.resultSet.close(function(err) {
                                            if (err) console.error(err.message);

                                            connection.release(function(err) {
                                                if (err) console.error(err.message);
                                            });
                                        });
                                    });

                                }

                                processResultSet();
                                /*try ends belo*/
                            } catch (ex) {
                                console.log(" ### Exception In ODS QUERY : " + ex);
                            }
                        } ///function(err, results) ENDS




                    );
                    /*TRY ENDS below*/
                } catch (ex) {
                    console.log(" ### Exception In ODS QUERY : " + ex);
                }
            } // function(err, connection) {

        );

    } catch (ex) {
        console.log(" ### Exception In ODS QUERY : " + ex);
    }



  //res.render('index', { title: 'Express' });
});

router.get('/query1', function(req, res, next) {
	console.log(" **** QUERY 1 CALLED *****");
	
	
})

module.exports = router;
